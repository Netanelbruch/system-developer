

// תוכנית 2: חלוקה באפס
#include <stdio.h>


int main() {
    int divisor = 0;
    int result = 10 / divisor;
    printf("This will cause a division by zero error: %d\n", result);
    return 0;
}


