
// תוכנית 1: גלישה מהמחסנית עקב רקורסיה אינסופית
#include <stdio.h>

void infiniteRecursion() {
    int array[1000];
    // printf("This will cause a stack overflow\n");
    infiniteRecursion();
}

int main() {
    infiniteRecursion();
    return 0;
}
