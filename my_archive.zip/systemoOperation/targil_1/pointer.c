// תוכנית 3: שימוש בזכרון לא מוגדר
#include <stdio.h>

int main() {
    int *undefinedMemory;
    *undefinedMemory = 10; // ניסיון לכתוב לכתובת לא מוגדרת
    printf("This will cause a segmentation fault: %d\n", *undefinedMemory);
    return 0;
}