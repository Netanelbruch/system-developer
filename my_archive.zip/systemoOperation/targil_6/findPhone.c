#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_PHONE_LENGTH 20

void findPhone(char *name) {
    int pipe1[2], pipe2[2];
    
    // Create pipes
    pipe(pipe1);
    pipe(pipe2);
    
    if (fork() == 0) {
        // Child process - grep
        close(pipe1[0]);
        dup2(pipe1[1], STDOUT_FILENO);
        execlp("grep", "grep", name, "Phonebook.txt", NULL);
    }

    // Parent process
    close(pipe1[1]);
    
    char phone[MAX_PHONE_LENGTH];
    FILE *pipe_stream = fdopen(pipe1[0], "r");
    if (pipe_stream == NULL) {
        perror("fdopen");
        exit(EXIT_FAILURE);
    }

    // Read the output of grep
    if (fgets(phone, MAX_PHONE_LENGTH, pipe_stream) != NULL) {
        printf("Phone number for %s: %s", name, phone);
    } else {
        printf("No phone number found for %s\n", name);
    }

    fclose(pipe_stream);
    close(pipe1[0]);
    
    // Wait for the child process to finish
    wait(NULL);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <name>\n", argv[0]);
        return 1;
    }

    char *name = argv[1];
    findPhone(name);

    return 0;
}
