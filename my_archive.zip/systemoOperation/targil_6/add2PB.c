
#include <stdio.h>

// פונקציה המוסיפה רשומה חדשה לקובץ הטקסט
void add2PB(char *name, char *phone_number, char *filename) {
    FILE *f = fopen(filename, "a");
    if (f == NULL) {
        printf("Error opening file!\n");
        return;
    }

    // כתיבת שם לקובץ
    fprintf(f, "%s,", name);

    // כתיבת מספר הטלפון לקובץ
    fprintf(f, "%s\n", phone_number);

    fclose(f);
}

int main() {
    char name[100];
    char phone_number[20];
    char filename[] = "Phonebook.txt";

    // בקשת קלט מהמשתמש לשם ומספר טלפון
    printf("Enter name and phone number (separated by comma): ");
    scanf("%99[^,\n]%*c", name); // קליטת השם עד לפסיק או לשורה חדשה ואז קריאת התו הנותר בזיכרון
    scanf("%19[^\n]%*c", phone_number); // קליטת מספר הטלפון עד לשורה חדשה ואז קריאת התו הנותר בזיכרון

    add2PB(name, phone_number, filename);

    printf("Record added to phonebook!\n");

    return 0;
}
